-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2021 at 12:13 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping cart eav`
--

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `ID` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`ID`, `Name`) VALUES
(1, 'Drug Strength'),
(2, 'Size'),
(3, 'Pills'),
(4, 'Expiry Date'),
(5, 'Amount');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `Price` int(11) NOT NULL,
  `Product_Type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `image`, `Price`, `Product_Type`) VALUES
(1, 'Face Mask', 'product-images/Face_mask.jfif', 5, 5),
(2, 'Face Mask with Filter', 'product-images/Mask_Filter.jfif', 10, 5),
(3, 'Hand Sanitizer', 'product-images/Sanitizer.jfif', 20, 4),
(4, 'Hand Sanitizer Alcohol Free', 'product-images/sanitizer2.jfif', 20, 4),
(5, 'Panadol', 'product-images/panadol.jfif', 25, 1),
(6, 'Panadol Syrup', 'product-images/Panadol_Syrup.jfif', 27, 6),
(7, 'Augmentin', 'product-images/Augmentin_Syrup.jfif', 40, 6);

-- --------------------------------------------------------

--
-- Table structure for table `product_s_o_v`
--

CREATE TABLE `product_s_o_v` (
  `ID` int(11) NOT NULL,
  `Product_ID` int(11) NOT NULL,
  `Product_Type_S_O` int(11) NOT NULL,
  `Value` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_s_o_v`
--

INSERT INTO `product_s_o_v` (`ID`, `Product_ID`, `Product_Type_S_O`, `Value`) VALUES
(1, 1, 4, '20'),
(2, 2, 4, '20'),
(3, 3, 6, '30ml'),
(4, 3, 5, '1'),
(5, 4, 6, '30ml'),
(6, 4, 5, '1'),
(7, 5, 2, '500mg'),
(8, 5, 1, '12'),
(9, 5, 3, '6 Months'),
(10, 6, 7, '120mg/5ml'),
(11, 6, 9, '70ml'),
(12, 6, 8, '1 week'),
(13, 7, 7, '228mg/5ml'),
(14, 7, 9, '80ml'),
(15, 7, 8, '1 week');

-- --------------------------------------------------------

--
-- Table structure for table `product_type`
--

CREATE TABLE `product_type` (
  `ID` int(11) NOT NULL,
  `Type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_type`
--

INSERT INTO `product_type` (`ID`, `Type`) VALUES
(1, 'Capsules'),
(2, 'Drops'),
(3, 'Injections'),
(4, 'Sanitizer'),
(5, 'Masks'),
(6, 'Syrup');

-- --------------------------------------------------------

--
-- Table structure for table `product_type_s_o`
--

CREATE TABLE `product_type_s_o` (
  `ID` int(11) NOT NULL,
  `Product_Type` int(11) NOT NULL,
  `Options` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_type_s_o`
--

INSERT INTO `product_type_s_o` (`ID`, `Product_Type`, `Options`) VALUES
(1, 1, 3),
(2, 1, 1),
(3, 1, 4),
(4, 5, 5),
(5, 4, 5),
(6, 4, 2),
(7, 6, 1),
(8, 6, 4),
(9, 6, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Product_Type` (`Product_Type`);

--
-- Indexes for table `product_s_o_v`
--
ALTER TABLE `product_s_o_v`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Product_ID` (`Product_ID`),
  ADD KEY `Option_ID` (`Product_Type_S_O`);

--
-- Indexes for table `product_type`
--
ALTER TABLE `product_type`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `product_type_s_o`
--
ALTER TABLE `product_type_s_o`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Product_Type` (`Product_Type`),
  ADD KEY `Options` (`Options`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `product_s_o_v`
--
ALTER TABLE `product_s_o_v`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `product_type`
--
ALTER TABLE `product_type`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product_type_s_o`
--
ALTER TABLE `product_type_s_o`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`Product_Type`) REFERENCES `product_type` (`ID`);

--
-- Constraints for table `product_s_o_v`
--
ALTER TABLE `product_s_o_v`
  ADD CONSTRAINT `product_s_o_v_ibfk_2` FOREIGN KEY (`Product_ID`) REFERENCES `product` (`id`),
  ADD CONSTRAINT `product_s_o_v_ibfk_3` FOREIGN KEY (`Product_Type_S_O`) REFERENCES `product_type_s_o` (`ID`);

--
-- Constraints for table `product_type_s_o`
--
ALTER TABLE `product_type_s_o`
  ADD CONSTRAINT `product_type_s_o_ibfk_1` FOREIGN KEY (`Product_Type`) REFERENCES `product_type` (`ID`),
  ADD CONSTRAINT `product_type_s_o_ibfk_2` FOREIGN KEY (`Options`) REFERENCES `options` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
