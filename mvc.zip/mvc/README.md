# New SE305 MVC PHP Framework

This document MVC for SE305 course at MIU.

## Description

Design and implement an **PHP MVC application**.  

## Useful Links
https://getbootstrap.com/docs/5.0/examples/