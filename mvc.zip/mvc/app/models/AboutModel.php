<?php
class AboutModel extends model
{
     public $title = 'About MIU SE305 Blog';
     public $data = 'Test Data';
}
