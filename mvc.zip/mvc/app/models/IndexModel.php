<?php
class IndexModel extends model
{
     public $title = 'MIU SE305 Blog ' . APP_VERSION;
     public $subtitle = 'Example of MVC PHP framework for SE305';
}
