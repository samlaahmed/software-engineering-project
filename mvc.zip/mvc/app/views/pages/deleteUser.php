<?php
// $this->ID=$_GET['id'];
$this->model->setID($_GET['id']);
class editUser extends view
{
  public function output()
  {
      
    // $title = $this->model->title;

    require APPROOT . '/views/inc/header.php';
    $text = <<<EOT
    
EOT;
    echo $text;
    $this->printForm();
    require APPROOT . '/views/inc/footer.php';
  }

  private function printForm()
  {
    $action = URLROOT . 'pages/edituser';
    // $loginUrl = URLROOT . 'users/login';
    $users = $this->model->ViewUser('1');

    $text = <<<EOT
    <div class="row">
    <div class="col-md-6 mx-auto">
    <div class="card card-body bg-secondary mt-5">
    <h2>Sign Up</h2>
    <form action="$action" method="post">
EOT;
    echo $text;
    $this->printName();
    // $this->printlName();
    $this->printEmail();
    $this->printPassword();
    $this->printConfirmPassword();
    $text = <<<EOT
    <div class="container">
      <div class="row mt-4">
        <div class="col">
          <input type="submit" value="Update" class="form-control btn btn-lg btn-primary btn-block">
        </div>
    
      </div>
      </div>
    </form>
    </div>
    </div>
    </div>
EOT;
    echo $text;
  }

  private function printName()
  {
    
    $val =  $GLOBALS['users']->name;
   
    $err = $this->model->getName();
    $valid = (!empty($err) ? 'is-invalid' : '');

    $this->printInput('text', 'name', $val, $err, $valid);
  }
  public function delete(){
    
    $sql = "DELETE FROM user WHERE id='" . $_GET['id'] . "'";
    deleteData($sql);
  
    
   }
   
  
}