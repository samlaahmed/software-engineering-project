<?php require APPROOT . '/views/inc/header.php';?>
  <h1><?php echo $data['val1']; ?></h1>
<?php require APPROOT . '/views/inc/footer.php';?>