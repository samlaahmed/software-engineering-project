<?php
require_once '../app/bootapp.php';

// Init Core Library
$init = new Core;
